$(document).ready(function() {

    /* Magic Validation */
    /*-----------------------------------------------------*/
    sweetDelete = function(text)
    {
          swal(
            'Terhapus !',
            text +' Berhasil Dihapus.',
            'success'
          )
    }
});
